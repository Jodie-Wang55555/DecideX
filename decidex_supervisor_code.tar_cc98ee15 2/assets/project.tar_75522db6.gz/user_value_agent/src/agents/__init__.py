"""
DecideX Agents 模块
"""

# 导入用户价值观 Agent
from agents.agent import build_agent

__all__ = ['build_agent']
